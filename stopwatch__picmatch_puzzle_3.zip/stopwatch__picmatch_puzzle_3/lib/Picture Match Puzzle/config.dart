int cur_level=0;
List level = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35];   // level show
List levels=[];                     // level status use
List level_puzzle = [8,10,12,14,16,18,20,20,20,20];   // no of image
List <bool> temp = [];                          // for image show
List<int> second=List.filled(level.length, 0);                 // store second
List myimg = [];              // image
List images=[];                     //image
int a=5,x1=0,x2=0;
int pos=1;



int time_level=0;
int b=5,s=30 , pos1=1,y1=0,y2=0;
List time=[];                   //for level status use
List <int> times=List.filled(level.length, 0);  // for store second

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:getwidget/components/animation/gf_animation.dart';
import 'Picture Match Puzzle/First Page.dart';
import 'Picture Match Puzzle/config.dart';

void main() {
  runApp(MaterialApp(
    home: FirstPage(),
    debugShowCheckedModeBanner: false,
  ));
}

//1 Stopwatch()
//2 FirstPage()

